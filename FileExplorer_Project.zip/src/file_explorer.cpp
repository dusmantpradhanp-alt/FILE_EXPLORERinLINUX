#include <iostream>
#include <filesystem>
#include <string>
#include <fstream>

namespace fs = std::filesystem;

class FileManager {
public:
    static void listFiles(const std::string& path = ".") {
        try {
            if (!fs::exists(path)) {
                std::cout << "Path does not exist: " << path << std::endl;
                return;
            }
            std::cout << "Listing contents of: " << fs::absolute(path) << std::endl;
            for (const auto& entry : fs::directory_iterator(path)) {
                std::cout << (fs::is_directory(entry) ? "[DIR]  " : "[FILE] ")
                          << entry.path().filename().string() << std::endl;
            }
        } catch (const std::exception& e) {
            std::cerr << "Error: " << e.what() << std::endl;
        }
    }

    static bool createFile(const std::string& filename) {
        std::ofstream ofs(filename, std::ios::app);
        return ofs.good();
    }

    static bool createDirectory(const std::string& dirname) {
        return fs::create_directories(dirname);
    }

    static bool removePath(const std::string& path) {
        if (!fs::exists(path)) return false;
        std::cout << "Are you sure you want to delete '" << path << "'? (yes/NO): ";
        std::string ans;
        std::getline(std::cin, ans);
        if (ans == "yes") {
            if (fs::is_directory(path))
                return fs::remove_all(path) > 0;
            else
                return fs::remove(path);
        }
        std::cout << "Aborted deletion." << std::endl;
        return false;
    }

    static bool copyPath(const std::string& src, const std::string& dst) {
        if (!fs::exists(src)) return false;
        if (fs::exists(dst)) {
            std::cout << "Destination exists. Overwrite? (yes/NO): ";
            std::string ans; std::getline(std::cin, ans);
            if (ans != "yes") return false;
        }
        fs::copy(src, dst, fs::copy_options::recursive | fs::copy_options::overwrite_existing);
        return true;
    }

    static bool movePath(const std::string& src, const std::string& dst) {
        if (!fs::exists(src)) return false;
        if (fs::exists(dst)) {
            std::cout << "Destination exists. Overwrite? (yes/NO): ";
            std::string ans; std::getline(std::cin, ans);
            if (ans != "yes") return false;
        }
        fs::rename(src, dst);
        return true;
    }
};

int main() {
    std::string path = ".";
    std::string cmd;

    while (true) {
        std::cout << "[" << fs::current_path() << "]$ ";
        std::getline(std::cin, cmd);

        if (cmd == "exit") break;
        else if (cmd.rfind("ls", 0) == 0) FileManager::listFiles();
        else if (cmd.rfind("touch ", 0) == 0) {
            std::string f = cmd.substr(6);
            if (FileManager::createFile(f)) std::cout << "Created file: " << f << "\n";
            else std::cout << "Failed to create file: " << f << "\n";
        }
        else if (cmd.rfind("mkdir ", 0) == 0) {
            std::string d = cmd.substr(6);
            if (FileManager::createDirectory(d)) std::cout << "Created directory: " << d << "\n";
            else std::cout << "Failed to create directory: " << d << "\n";
        }
        else if (cmd.rfind("rm ", 0) == 0) {
            std::string p = cmd.substr(3);
            if (FileManager::removePath(p)) std::cout << "Deleted: " << p << "\n";
        }
        else if (cmd.rfind("cp ", 0) == 0) {
            size_t space = cmd.find(' ', 3);
            if (space != std::string::npos) {
                std::string src = cmd.substr(3, space-3);
                std::string dst = cmd.substr(space+1);
                if (FileManager::copyPath(src, dst)) std::cout << "Copied successfully.\n";
            }
        }
        else if (cmd.rfind("mv ", 0) == 0) {
            size_t space = cmd.find(' ', 3);
            if (space != std::string::npos) {
                std::string src = cmd.substr(3, space-3);
                std::string dst = cmd.substr(space+1);
                if (FileManager::movePath(src, dst)) std::cout << "Moved successfully.\n";
            }
        }
        else {
            std::cout << "Unknown command. Available: ls, touch, mkdir, rm, cp, mv, exit\n";
        }
    }
    return 0;
}
