# Console File Explorer (Linux - C++)

## 🧭 Overview
A **console-based file explorer** built in **C++17** that interacts directly with the Linux filesystem.  
It supports navigation, file search, and permission management via simple terminal commands.

---

## ⚙️ Features
✅ List files and directories  
✅ Navigate through directories (`cd`)  
✅ Search files and folders recursively (`search`)  
✅ View file permissions (`perm`)  
✅ Modify file permissions (`chmod`)  
✅ Easy to extend (copy, move, delete, etc.)  

---

## 🧩 Project Structure
```
FileExplorer/
│
├── include/              # Header files (future expansion)
├── src/                  # Source code files
│   └── file_explorer.cpp # Main application file
├── build/                # Generated executables
├── Makefile              # Build automation
└── README.md             # Documentation
```

---

## 🧱 Setup & Compilation

### 1️⃣ Install Dependencies
Make sure you have a **C++17** compiler and `make` installed:
```bash
sudo apt update
sudo apt install g++ make
```

### 2️⃣ Build the Project
```bash
make
```

### 3️⃣ Run the Explorer
```bash
./build/file_explorer
```

---

## 🖥️ Commands

| Command | Description | Example |
|----------|--------------|----------|
| `ls` | List files in current directory | `ls` |
| `cd <dir>` | Change directory | `cd Documents` |
| `search <term>` | Search recursively for files/folders | `search test` |
| `perm <file>` | Show permissions of a file | `perm notes.txt` |
| `chmod <mode> <file>` | Change permissions (octal format) | `chmod 755 notes.txt` |
| `exit` | Quit the explorer | `exit` |

---

## 🔐 File Permission Notes
Permissions use **Linux octal format** (like `chmod` command):
- `7` = read + write + execute
- `6` = read + write
- `5` = read + execute

Example:
```bash
chmod 755 script.sh
```
Gives **full access to owner**, and **read+execute** to others.

---

## 🧰 Future Enhancements
- Copy, Move, Delete files (`cp`, `mv`, `rm`)
- File creation (`touch`)
- Display CPU/Memory usage
- System update/cleanup script integration
- GUI-like navigation with ncurses

---

## 👨‍💻 Author
Developed by **BABAMANI PRADHAN**  
Language: **C++17**  
Platform: **Linux (Console Application)**

---

## 📜 License
Free to use and modify for educational or personal projects.
